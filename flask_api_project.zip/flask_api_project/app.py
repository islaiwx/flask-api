from flask import Flask, request, jsonify, g
import sqlite3
import queue
import uuid
import ssl

app = Flask(__name__)

# In-memory queue to simulate queue management
request_queue = queue.Queue()

# Simple token-based authentication
AUTH_TOKEN = "your_static_token"

# Database setup
DATABASE = 'requests.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

def init_db():
    with app.app_context():
        db = get_db()
        db.execute('''CREATE TABLE IF NOT EXISTS requests (
            id TEXT PRIMARY KEY,
            query TEXT NOT NULL,
            status TEXT NOT NULL,
            result TEXT
        )''')
        db.commit()

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Token verification decorator
def token_required(f):
    def wrap(*args, **kwargs):
        token = request.headers.get('Authorization')
        if token == AUTH_TOKEN:
            return f(*args, **kwargs)
        else:
            return jsonify({'message': 'Invalid or missing token'}), 401
    return wrap

# API Endpoints
@app.route('/submit-request', methods=['POST'])
@token_required
def submit_request():
    data = request.json
    if 'query' not in data:
        return jsonify({'message': 'Query is required'}), 400

    request_id = str(uuid.uuid4())
    query = data['query']

    # Add request to the queue
    request_queue.put(request_id)

    # Save request in the database
    db = get_db()
    db.execute("INSERT INTO requests (id, query, status) VALUES (?, ?, ?)",
               (request_id, query, 'queued'))
    db.commit()

    return jsonify({'request_id': request_id}), 201

@app.route('/fetch-requests', methods=['GET'])
@token_required
def fetch_requests():
    if request_queue.empty():
        return jsonify({'message': 'No requests in the queue'}), 200

    request_id = request_queue.get()

    db = get_db()
    cursor = db.execute("SELECT query FROM requests WHERE id = ?", (request_id,))
    query = cursor.fetchone()[0]

    return jsonify({'request_id': request_id, 'query': query}), 200

@app.route('/submit-result', methods=['POST'])
@token_required
def submit_result():
    data = request.json
    if 'request_id' not in data or 'result' not in data:
        return jsonify({'message': 'Request ID and result are required'}), 400

    request_id = data['request_id']
    result = data['result']

    db = get_db()
    db.execute("UPDATE requests SET status = ?, result = ? WHERE id = ?",
               ('completed', result, request_id))
    db.commit()

    return jsonify({'message': 'Result submitted successfully'}), 200

@app.route('/get-result/<request_id>', methods=['GET'])
@token_required
def get_result(request_id):
    db = get_db()
    cursor = db.execute("SELECT status, result FROM requests WHERE id = ?", (request_id,))
    row = cursor.fetchone()

    if row is None:
        return jsonify({'message': 'Request not found'}), 404

    status, result = row

    if status != 'completed':
        return jsonify({'message': 'Request is not yet completed'}), 200

    return jsonify({'result': result}), 200

if __name__ == '__main__':
    init_db()

    # SSL context for HTTPS
    context = ssl.SSLContext(ssl.PROTOCOL_TLS)
    context.load_cert_chain('cert.pem', 'key.pem')

    app.run(host='0.0.0.0', port=5000, ssl_context=context)
